import { API_KEY, ALPHA_VANTAGE_API_KEY } from './apiKeys';

export const fetchQuote = async (symbol: string) => {
  try {
    const url = `https://finnhub.io/api/v1/quote?symbol=${symbol}&token=${API_KEY}`;
    const response = await fetch(url);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching quote:', error);
    return null;
  }
};

export const fetchIndicator = async (
  symbol: string,
  indicator: string,
  from: number,
  to: number,
  timeperiod: number
) => {
  try {
    const url = `https://finnhub.io/api/v1/indicator?symbol=${symbol}&resolution=1&from=${from}&to=${to}&indicator=${indicator}&timeperiod=${timeperiod}&token=${API_KEY}`;
    const response = await fetch(url);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error(`Error fetching ${indicator}:`, error);
    return null;
  }
};

export const fetchCandlestickData = async (symbol: string) => {
  try {
    const url = `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&apikey=${ALPHA_VANTAGE_API_KEY}`;
    const response = await fetch(url);
    const data = await response.json();
    
    if (!data['Time Series (Daily)']) {
      return [];
    }
    
    const timeSeries = data['Time Series (Daily)'];
    return Object.keys(timeSeries).slice(0, 30).map(date => {
      const dayData = timeSeries[date];
      return {
        x: new Date(date),
        y: [
          parseFloat(dayData['1. open']),
          parseFloat(dayData['2. high']),
          parseFloat(dayData['3. low']),
          parseFloat(dayData['4. close'])
        ]
      };
    }).reverse();
  } catch (error) {
    console.error('Error fetching candlestick data:', error);
    return [];
  }
};

export const fetchCompanyNews = async (symbol: string) => {
  try {
    const today = new Date().toISOString().split("T")[0];
    const from = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
    
    const url = `https://finnhub.io/api/v1/company-news?symbol=${symbol}&from=${from}&to=${today}&token=${API_KEY}`;
    const response = await fetch(url);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching company news:', error);
    return [];
  }
};