// API keys for stock data services
export const API_KEY = "cvtobvhr01qjg135bp5gcvtobvhr01qjg135bp60";
export const ALPHA_VANTAGE_API_KEY = "N5P8LHI5XRGN63C1";