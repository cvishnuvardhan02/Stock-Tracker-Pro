import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import BeginnerGuide from './components/BeginnerGuide';
import StockQuiz from './components/StockQuiz';
import ChatBot from './components/ChatBot';
import { StockProvider } from './context/StockContext';

function App() {
  return (
    <Router>
      <StockProvider>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
          <Header />
          <main className="container mx-auto px-4 py-6">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/guide" element={<BeginnerGuide />} />
              <Route path="/quiz" element={<StockQuiz />} />
              <Route path="/chat" element={<ChatBot />} />
            </Routes>
          </main>
          <footer className="container mx-auto px-4 py-6 text-center text-slate-400 text-sm">
            <p>© {new Date().getFullYear()} Stock Tracker Pro. All market data provided by Finnhub.</p>
          </footer>
        </div>
      </StockProvider>
    </Router>
  );
}

export default App;