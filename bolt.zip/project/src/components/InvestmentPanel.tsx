import React, { useState } from 'react';
import { DollarSign, TrendingUp, TrendingDown } from 'lucide-react';
import { useStockContext } from '../context/StockContext';

const InvestmentPanel: React.FC = () => {
  const { currentStock, ticker, investInStock, sellStock, balance, investedAmount, investmentStatus } = useStockContext();
  const [amount, setAmount] = useState('');

  const handleInvest = () => {
    const value = parseFloat(amount);
    if (!isNaN(value) && value > 0) {
      investInStock(value);
      setAmount('');
    }
  };

  const handleSell = () => {
    sellStock();
  };

  return (
    <div className="bg-slate-800/60 backdrop-blur-md border border-slate-700 rounded-xl p-4 animate-fade-in h-full">
      <h2 className="text-xl font-bold mb-4 flex items-center">
        <DollarSign className="w-5 h-5 text-green-400 mr-2" />
        Investment Simulator
      </h2>
      
      <div className="mb-4 p-3 bg-slate-700/50 rounded-lg">
        <p className="text-sm text-slate-400">Your Balance</p>
        <p className="text-2xl font-bold">${balance.toFixed(2)}</p>
      </div>
      
      {investedAmount > 0 && (
        <div className="mb-4 p-3 bg-slate-700/50 rounded-lg">
          <p className="text-sm text-slate-400">Invested in {ticker}</p>
          <p className="text-xl font-medium">${investedAmount.toFixed(2)}</p>
          
          {currentStock && investmentStatus?.purchasedPrice && (
            <div className="mt-2">
              <div className="flex items-center text-sm">
                <p className="text-slate-400 mr-2">Current P/L:</p>
                <div className={`flex items-center ${
                  currentStock.c > investmentStatus.purchasedPrice ? 'text-green-400' : 'text-red-400'
                }`}>
                  {currentStock.c > investmentStatus.purchasedPrice 
                    ? <TrendingUp className="w-4 h-4 mr-1" /> 
                    : <TrendingDown className="w-4 h-4 mr-1" />
                  }
                  <span>
                    ${((currentStock.c - investmentStatus.purchasedPrice) * 
                      (investedAmount / investmentStatus.purchasedPrice)).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
      
      <div className="mb-4">
        <label htmlFor="investAmount" className="block text-sm font-medium text-slate-300 mb-1">
          Amount to Invest
        </label>
        <input
          id="investAmount"
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Enter amount"
          className="w-full bg-slate-700/50 border border-slate-600 rounded-lg p-2.5 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={handleInvest}
          disabled={!amount || parseFloat(amount) <= 0 || parseFloat(amount) > balance || !currentStock}
          className={`px-4 py-2.5 rounded-lg font-medium transition-colors ${
            !amount || parseFloat(amount) <= 0 || parseFloat(amount) > balance || !currentStock
              ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
              : 'bg-green-500 hover:bg-green-600 text-white'
          }`}
        >
          Buy
        </button>
        
        <button
          onClick={handleSell}
          disabled={investedAmount <= 0}
          className={`px-4 py-2.5 rounded-lg font-medium transition-colors ${
            investedAmount <= 0
              ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
              : 'bg-red-500 hover:bg-red-600 text-white'
          }`}
        >
          Sell
        </button>
      </div>
      
      {investmentStatus?.message && (
        <div className={`mt-4 p-3 rounded-lg text-sm ${
          investmentStatus.type === 'success' ? 'bg-green-500/20 text-green-300' : 
          investmentStatus.type === 'error' ? 'bg-red-500/20 text-red-300' :
          'bg-blue-500/20 text-blue-300'
        }`}>
          {investmentStatus.message}
        </div>
      )}
    </div>
  );
};

export default InvestmentPanel;