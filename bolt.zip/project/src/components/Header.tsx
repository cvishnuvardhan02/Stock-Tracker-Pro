import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { TrendingUp, BookOpen, MessageSquare, BrainCircuit } from 'lucide-react';

const Header: React.FC = () => {
  const location = useLocation();

  return (
    <header className="bg-slate-800/80 backdrop-blur-md sticky top-0 z-10 border-b border-slate-700">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2">
          <TrendingUp className="text-blue-400 w-8 h-8" />
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent">
            Stock Tracker Pro
          </h1>
        </Link>
        <nav className="flex gap-4">
          <Link
            to="/guide"
            className={`flex items-center gap-1 transition-colors ${
              location.pathname === '/guide' ? 'text-white' : 'text-slate-300 hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Beginner Guide</span>
          </Link>
          <Link
            to="/quiz"
            className={`flex items-center gap-1 transition-colors ${
              location.pathname === '/quiz' ? 'text-white' : 'text-slate-300 hover:text-white'
            }`}
          >
            <BrainCircuit className="w-4 h-4" />
            <span>Quiz</span>
          </Link>
          <Link
            to="/chat"
            className={`flex items-center gap-1 transition-colors ${
              location.pathname === '/chat' ? 'text-white' : 'text-slate-300 hover:text-white'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Chat Assistant</span>
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;