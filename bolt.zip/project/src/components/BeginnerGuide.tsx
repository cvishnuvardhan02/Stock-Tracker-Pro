import React from 'react';
import { BookOpen, TrendingUp, DollarSign, Clock, Target, AlertTriangle } from 'lucide-react';

const BeginnerGuide: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto bg-slate-800 rounded-xl shadow-xl">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <BookOpen className="w-8 h-8 text-blue-400" />
          <h2 className="text-2xl font-bold">Stock Market Guide for Beginners</h2>
        </div>

        <div className="space-y-6">
          <section>
            <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              Understanding the Basics
            </h3>
            <div className="space-y-3 text-slate-300">
              <p>The stock market is a place where shares of publicly traded companies are bought and sold. When you buy a stock, you're purchasing a small ownership stake in a company.</p>
              <p>Key terms to understand:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Stock/Share: A piece of ownership in a company</li>
                <li>Dividend: A portion of company profits paid to shareholders</li>
                <li>Market Cap: Total value of a company's shares</li>
                <li>Volume: Number of shares traded in a day</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-400" />
              Getting Started with Investing
            </h3>
            <div className="space-y-3 text-slate-300">
              <p>Before investing, consider these steps:</p>
              <ol className="list-decimal list-inside space-y-2 ml-4">
                <li>Set clear financial goals</li>
                <li>Create an emergency fund first</li>
                <li>Understand your risk tolerance</li>
                <li>Research and choose a reliable broker</li>
                <li>Start with a diversified portfolio</li>
              </ol>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
              <Target className="w-5 h-5 text-green-400" />
              Investment Strategies
            </h3>
            <div className="space-y-3 text-slate-300">
              <p>Common investment strategies include:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Buy and Hold: Long-term investment in stable companies</li>
                <li>Dollar-Cost Averaging: Investing fixed amounts regularly</li>
                <li>Dividend Investing: Focus on dividend-paying stocks</li>
                <li>Growth Investing: Investing in companies with high growth potential</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
              <Clock className="w-5 h-5 text-green-400" />
              When to Buy and Sell
            </h3>
            <div className="space-y-3 text-slate-300">
              <p>Consider these factors when timing your trades:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Company fundamentals and financial health</li>
                <li>Market trends and conditions</li>
                <li>Economic indicators</li>
                <li>Industry performance</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
              Common Mistakes to Avoid
            </h3>
            <div className="space-y-3 text-slate-300">
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Investing without research</li>
                <li>Trying to time the market perfectly</li>
                <li>Letting emotions drive decisions</li>
                <li>Not diversifying your portfolio</li>
                <li>Investing money you can't afford to lose</li>
              </ul>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default BeginnerGuide;