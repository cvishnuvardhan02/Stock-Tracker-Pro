import React from 'react';
import StockSearch from './StockSearch';
import PriceChart from './PriceChart';
import InvestmentPanel from './InvestmentPanel';
import NewsPanel from './NewsPanel';
import StockSummary from './StockSummary';
import { useStockContext } from '../context/StockContext';

const Dashboard: React.FC = () => {
  const { currentStock } = useStockContext();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-4">
      <div className="lg:col-span-12">
        <StockSearch />
      </div>
      
      {currentStock && (
        <>
          <div className="lg:col-span-8">
            <StockSummary />
          </div>
          
          <div className="lg:col-span-4">
            <div className="bg-slate-800/60 backdrop-blur-md border border-slate-700 rounded-xl p-4 animate-fade-in">
              <h2 className="text-xl font-bold mb-4">Market Stats</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-700/50 p-3 rounded-lg">
                  <p className="text-sm text-slate-400">Open</p>
                  <p className="text-lg font-medium">${currentStock.o.toFixed(2)}</p>
                </div>
                <div className="bg-slate-700/50 p-3 rounded-lg">
                  <p className="text-sm text-slate-400">High</p>
                  <p className="text-lg font-medium">${currentStock.h.toFixed(2)}</p>
                </div>
                <div className="bg-slate-700/50 p-3 rounded-lg">
                  <p className="text-sm text-slate-400">Low</p>
                  <p className="text-lg font-medium">${currentStock.l.toFixed(2)}</p>
                </div>
                <div className="bg-slate-700/50 p-3 rounded-lg">
                  <p className="text-sm text-slate-400">Prev. Close</p>
                  <p className="text-lg font-medium">${currentStock.pc.toFixed(2)}</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-12">
            <div className="bg-slate-800/60 backdrop-blur-md border border-slate-700 rounded-xl p-4 animate-fade-in">
              <h2 className="text-xl font-bold mb-4">Price Chart</h2>
              <PriceChart />
            </div>
          </div>
          
          <div className="lg:col-span-4">
            <InvestmentPanel />
          </div>
          
          <div className="lg:col-span-8">
            <NewsPanel />
          </div>
        </>
      )}
      
      {!currentStock && (
        <div className="lg:col-span-12 flex flex-col items-center justify-center py-16 text-center">
          <div className="max-w-md">
            <h2 className="text-2xl font-bold mb-4">Welcome to Stock Tracker Pro</h2>
            <p className="text-slate-400 mb-8">
              Enter a stock ticker above to start tracking real-time prices, indicators, and news.
            </p>
            <div className="flex justify-center">
              <div className="flex gap-2 text-sm">
                <span className="px-2 py-1 bg-slate-700 rounded">AAPL</span>
                <span className="px-2 py-1 bg-slate-700 rounded">MSFT</span>
                <span className="px-2 py-1 bg-slate-700 rounded">TSLA</span>
                <span className="px-2 py-1 bg-slate-700 rounded">AMZN</span>
                <span className="px-2 py-1 bg-slate-700 rounded">GOOGL</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;