import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { useStockContext } from '../context/StockContext';

const StockSearch: React.FC = () => {
  const { startTracking, isLoading } = useStockContext();
  const [ticker, setTicker] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (ticker.trim()) {
      startTracking(ticker.trim().toUpperCase());
    }
  };

  return (
    <div className="bg-slate-800/60 backdrop-blur-md border border-slate-700 rounded-xl p-6 animate-fade-in">
      <h2 className="text-xl font-bold mb-4">Search Stock</h2>
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            type="text"
            value={ticker}
            onChange={(e) => setTicker(e.target.value)}
            placeholder="Enter stock ticker (e.g., AAPL, MSFT, TSLA)"
            className="w-full bg-slate-700/50 border border-slate-600 rounded-lg py-3 pl-10 pr-4 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <button
          type="submit"
          disabled={isLoading || !ticker.trim()}
          className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 ${
            isLoading || !ticker.trim()
              ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
              : 'bg-blue-500 hover:bg-blue-600 text-white'
          }`}
        >
          {isLoading ? 'Loading...' : 'Track Stock'}
        </button>
      </form>
      <div className="mt-4 flex flex-wrap gap-2">
        <p className="text-sm text-slate-400">Popular tickers:</p>
        {['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA'].map((suggestion) => (
          <button
            key={suggestion}
            onClick={() => setTicker(suggestion)}
            className="text-sm px-2 py-1 bg-slate-700 hover:bg-slate-600 rounded transition-colors"
          >
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  );
};

export default StockSearch;