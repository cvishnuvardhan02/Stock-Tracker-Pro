import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { useStockContext } from '../context/StockContext';

const StockSummary: React.FC = () => {
  const { currentStock, stockInfo } = useStockContext();

  if (!currentStock || !stockInfo) return null;

  const priceChange = currentStock.c - currentStock.pc;
  const percentChange = (priceChange / currentStock.pc) * 100;
  const isPositive = priceChange >= 0;

  return (
    <div className="bg-slate-800/60 backdrop-blur-md border border-slate-700 rounded-xl p-4 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">{stockInfo.ticker}</h2>
          <p className="text-slate-400">{stockInfo.name || 'Stock'}</p>
        </div>
        
        <div className="flex flex-col items-end">
          <div className="flex items-center">
            <span className="text-3xl font-bold">${currentStock.c.toFixed(2)}</span>
            <div className={`flex items-center ml-3 ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
              {isPositive ? <TrendingUp className="w-5 h-5 mr-1" /> : <TrendingDown className="w-5 h-5 mr-1" />}
              <span className="font-medium">{Math.abs(priceChange).toFixed(2)}</span>
              <span className="ml-1">({Math.abs(percentChange).toFixed(2)}%)</span>
            </div>
          </div>
          <p className="text-sm text-slate-400">Last updated: {new Date().toLocaleTimeString()}</p>
        </div>
      </div>
    </div>
  );
};

export default StockSummary;