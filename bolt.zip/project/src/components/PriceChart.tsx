import React, { useEffect, useRef, useState } from 'react';
import Chart from 'chart.js/auto';
import { useStockContext } from '../context/StockContext';

const PriceChart: React.FC = () => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  const { chartData, ticker } = useStockContext();
  const [chartType, setChartType] = useState<'line' | 'bar' | 'area'>('line');

  useEffect(() => {
    if (!chartRef.current || !chartData.labels.length) return;

    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, 'rgba(56, 189, 248, 0.3)');
    gradient.addColorStop(1, 'rgba(56, 189, 248, 0)');

    chartInstance.current = new Chart(ctx, {
      type: chartType === 'area' ? 'line' : chartType,
      data: {
        labels: chartData.labels,
        datasets: [
          {
            label: `${ticker} Price`,
            data: chartData.prices,
            borderColor: 'rgb(56, 189, 248)',
            backgroundColor: chartType === 'area' ? gradient : 'rgba(56, 189, 248, 0.5)',
            borderWidth: 2,
            fill: chartType === 'area',
            tension: 0.4,
            pointRadius: 0,
            pointHoverRadius: 5,
          },
          {
            label: 'SMA (5)',
            data: chartData.sma,
            borderColor: 'rgb(251, 146, 60)',
            borderWidth: 2,
            borderDash: [5, 5],
            fill: false,
            tension: 0.1,
            pointRadius: 0,
          },
          {
            label: 'EMA (5)',
            data: chartData.ema,
            borderColor: 'rgb(192, 132, 252)',
            borderWidth: 2,
            borderDash: [5, 2],
            fill: false,
            tension: 0.1,
            pointRadius: 0,
          },
        ],
      },
      options: {
        responsive: true,
        animation: {
          duration: 1000,
          easing: 'easeOutQuart',
        },
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: {
              color: 'rgb(226, 232, 240)',
              font: {
                size: 12,
              },
            },
          },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: 'rgba(15, 23, 42, 0.9)',
            titleColor: 'rgb(226, 232, 240)',
            bodyColor: 'rgb(226, 232, 240)',
            borderColor: 'rgba(51, 65, 85, 0.8)',
            borderWidth: 1,
            padding: 10,
            cornerRadius: 6,
          },
        },
        scales: {
          x: {
            grid: {
              display: false,
              drawBorder: false,
            },
            ticks: {
              maxTicksLimit: 8,
              color: 'rgb(148, 163, 184)',
              font: {
                size: 10,
              },
            },
          },
          y: {
            grid: {
              color: 'rgba(51, 65, 85, 0.4)',
              drawBorder: false,
            },
            ticks: {
              color: 'rgb(148, 163, 184)',
              font: {
                size: 10,
              },
              callback: function(value) {
                return '$' + value;
              },
            },
          },
        },
        interaction: {
          mode: 'nearest',
          axis: 'x',
          intersect: false,
        },
      },
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
        chartInstance.current = null;
      }
    };
  }, [chartData, ticker, chartType]);

  return (
    <div>
      <div className="flex items-center gap-4 mb-4">
        <div className="flex gap-2">
          <button
            onClick={() => setChartType('line')}
            className={`px-3 py-1 rounded ${
              chartType === 'line'
                ? 'bg-blue-500 text-white'
                : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
            }`}
          >
            Line
          </button>
          <button
            onClick={() => setChartType('bar')}
            className={`px-3 py-1 rounded ${
              chartType === 'bar'
                ? 'bg-blue-500 text-white'
                : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
            }`}
          >
            Bar
          </button>
          <button
            onClick={() => setChartType('area')}
            className={`px-3 py-1 rounded ${
              chartType === 'area'
                ? 'bg-blue-500 text-white'
                : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
            }`}
          >
            Area
          </button>
        </div>
      </div>
      <div className="relative h-[300px] md:h-[400px]">
        <canvas ref={chartRef}></canvas>
      </div>
    </div>
  );
};

export default PriceChart;