import React, { useState } from 'react';
import { MessageSquare, Send } from 'lucide-react';

interface Message {
  text: string;
  isBot: boolean;
}

const stockResponses = {
  "what is a stock": "A stock represents ownership in a company. When you buy a stock, you're purchasing a small piece of that company and become a shareholder.",
  "how do i start investing": "To start investing: 1) Research and choose a reliable broker 2) Start with a diversified portfolio 3) Consider low-cost index funds 4) Only invest what you can afford to lose 5) Keep learning about markets and investing strategies.",
  "what is dividends": "Dividends are payments made by companies to their shareholders, typically from profits. They're usually paid quarterly and can provide regular income from your investments.",
  "what is market cap": "Market capitalization (market cap) is the total value of a company's shares. It's calculated by multiplying the current share price by the total number of outstanding shares.",
  "what is pe ratio": "The Price-to-Earnings (P/E) ratio is a valuation metric that compares a company's stock price to its earnings per share. It indicates how much investors are willing to pay for each dollar of earnings.",
  "what are technical indicators": "Technical indicators are mathematical calculations based on price, volume, or open interest of a security. Common indicators include Moving Averages (MA), Relative Strength Index (RSI), and MACD.",
  "what is day trading": "Day trading involves buying and selling securities within the same trading day. Day traders attempt to profit from short-term price movements but face higher risks and need significant market knowledge.",
  "what is fundamental analysis": "Fundamental analysis evaluates a company's intrinsic value by examining economic and financial factors. This includes analyzing financial statements, economic conditions, and industry trends.",
  "what is volatility": "Volatility measures how much a stock's price fluctuates over time. Higher volatility means larger price swings and potentially higher risk and reward.",
  "default": "I'm here to help with stock-related questions. You can ask about basic concepts, investment strategies, or specific market terms. If you're new to investing, consider checking out our Beginner's Guide!"
};

const ChatBot: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      text: "Hello! I'm your stock market assistant. How can I help you today?",
      isBot: true
    }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage = input.trim().toLowerCase();
    setMessages(prev => [...prev, { text: input, isBot: false }]);
    setInput('');

    // Find the most relevant response
    let response = stockResponses.default;
    for (const [key, value] of Object.entries(stockResponses)) {
      if (userMessage.includes(key)) {
        response = value;
        break;
      }
    }

    setTimeout(() => {
      setMessages(prev => [...prev, { text: response, isBot: true }]);
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-slate-800 rounded-xl shadow-xl">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <MessageSquare className="w-8 h-8 text-blue-400" />
          <h2 className="text-2xl font-bold">Stock Market Assistant</h2>
        </div>

        <div className="h-[400px] overflow-y-auto mb-4 space-y-4">
          {messages.map((message, index) =>
            message.isBot ? (
              <div key={index} className="flex items-start gap-2">
                <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                  <MessageSquare className="w-4 h-4" />
                </div>
                <div className="bg-slate-700 rounded-lg p-3 max-w-[80%]">
                  <p className="text-slate-200">{message.text}</p>
                </div>
              </div>
            ) : (
              <div key={index} className="flex items-start gap-2 justify-end">
                <div className="bg-blue-500 rounded-lg p-3 max-w-[80%]">
                  <p className="text-white">{message.text}</p>
                </div>
              </div>
            )
          )}
        </div>

        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask about stocks..."
            className="flex-1 bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim()}
            className="bg-blue-500 hover:bg-blue-600 disabled:bg-slate-700 disabled:cursor-not-allowed text-white p-2 rounded-lg transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatBot;