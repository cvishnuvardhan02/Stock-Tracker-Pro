import React, { useState } from 'react';
import { BrainCircuit, CheckCircle2, XCircle } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

const quizQuestions: Question[] = [
  {
    id: 1,
    question: "What is market capitalization?",
    options: [
      "The total number of shares traded in a day",
      "The total dollar value of a company's outstanding shares",
      "The price of a single share",
      "The company's yearly revenue"
    ],
    correctAnswer: 1,
    explanation: "Market capitalization (market cap) is calculated by multiplying a company's share price by its total number of outstanding shares. It represents the total value of a company in the stock market."
  },
  {
    id: 2,
    question: "Which of these is considered a defensive stock?",
    options: [
      "Tesla (TSLA)",
      "Procter & Gamble (PG)",
      "Bitcoin ETF",
      "GameStop (GME)"
    ],
    correctAnswer: 1,
    explanation: "Defensive stocks are shares in companies that provide essential goods/services (like P&G's consumer products) and tend to perform steadily regardless of economic conditions."
  },
  {
    id: 3,
    question: "What does a P/E ratio indicate?",
    options: [
      "Price to Earnings - how much investors pay for each dollar of earnings",
      "Profit to Expense - how profitable a company is",
      "Price to Equity - the company's stock price divided by equity",
      "Performance to Expectation - how well a stock performs vs expectations"
    ],
    correctAnswer: 0,
    explanation: "The Price-to-Earnings (P/E) ratio measures how much investors are willing to pay for each dollar of a company's earnings. It's calculated by dividing the stock price by earnings per share."
  },
  {
    id: 4,
    question: "What typically happens to defensive stocks during a recession?",
    options: [
      "They become more volatile",
      "They stop paying dividends",
      "They tend to remain relatively stable",
      "They always increase in value"
    ],
    correctAnswer: 2,
    explanation: "Defensive stocks typically remain relatively stable during recessions because they represent companies that sell essential products or services that people need regardless of economic conditions."
  },
  {
    id: 5,
    question: "Which factor does NOT directly affect stock prices?",
    options: [
      "Company earnings",
      "Interest rates",
      "The company's logo color",
      "Market sentiment"
    ],
    correctAnswer: 2,
    explanation: "While factors like earnings, interest rates, and market sentiment directly impact stock prices, cosmetic elements like a company's logo color have no direct effect on stock valuation."
  }
];

const StockQuiz: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [quizComplete, setQuizComplete] = useState(false);

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    setShowExplanation(true);
    
    if (answerIndex === quizQuestions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      setQuizComplete(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setScore(0);
    setQuizComplete(false);
  };

  return (
    <div className="max-w-2xl mx-auto bg-slate-800 rounded-xl shadow-xl">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <BrainCircuit className="w-8 h-8 text-purple-400" />
          <h2 className="text-2xl font-bold">Stock Market Quiz</h2>
        </div>

        {!quizComplete ? (
          <>
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-slate-400">Question {currentQuestion + 1} of {quizQuestions.length}</span>
                <span className="text-sm text-slate-400">Score: {score}</span>
              </div>
              <div className="w-full bg-slate-700 rounded-full h-2">
                <div 
                  className="bg-purple-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentQuestion + 1) / quizQuestions.length) * 100}%` }}
                ></div>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-xl font-medium mb-4">{quizQuestions[currentQuestion].question}</h3>
              <div className="space-y-3">
                {quizQuestions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    disabled={showExplanation}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${
                      selectedAnswer === null
                        ? 'bg-slate-700 hover:bg-slate-600'
                        : selectedAnswer === index
                        ? index === quizQuestions[currentQuestion].correctAnswer
                          ? 'bg-green-500/20 border border-green-500'
                          : 'bg-red-500/20 border border-red-500'
                        : index === quizQuestions[currentQuestion].correctAnswer && showExplanation
                        ? 'bg-green-500/20 border border-green-500'
                        : 'bg-slate-700 opacity-50'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>

            {showExplanation && (
              <div className="mb-6 p-4 bg-slate-700/50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  {selectedAnswer === quizQuestions[currentQuestion].correctAnswer ? (
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                  ) : (
                    <XCircle className="w-5 h-5 text-red-400" />
                  )}
                  <span className="font-medium">
                    {selectedAnswer === quizQuestions[currentQuestion].correctAnswer ? 'Correct!' : 'Incorrect'}
                  </span>
                </div>
                <p className="text-slate-300">{quizQuestions[currentQuestion].explanation}</p>
              </div>
            )}

            {showExplanation && (
              <button
                onClick={handleNextQuestion}
                className="w-full bg-purple-500 hover:bg-purple-600 text-white py-3 rounded-lg font-medium transition-colors"
              >
                {currentQuestion < quizQuestions.length - 1 ? 'Next Question' : 'Complete Quiz'}
              </button>
            )}
          </>
        ) : (
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Quiz Complete!</h3>
            <p className="text-xl mb-6">Your Score: {score} out of {quizQuestions.length}</p>
            <button
              onClick={resetQuiz}
              className="bg-purple-500 hover:bg-purple-600 text-white px-6 py-3 rounded-lg font-medium transition-colors"
            >
              Try Again
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default StockQuiz;