import React, { useEffect, useRef } from 'react';
import ApexCharts from 'apexcharts';
import { useStockContext } from '../context/StockContext';

const CandlestickChart: React.FC = () => {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<ApexCharts | null>(null);
  const { candlestickData, ticker } = useStockContext();

  useEffect(() => {
    if (!chartRef.current || !candlestickData.length) return;

    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const options = {
      series: [{
        name: 'Candle',
        data: candlestickData
      }],
      chart: {
        type: 'candlestick',
        height: 400,
        background: 'transparent',
        toolbar: {
          show: true,
          tools: {
            download: false,
          },
        },
        animations: {
          enabled: true,
          easing: 'easeinout',
          speed: 800,
        },
      },
      title: {
        text: `${ticker} Historical Data`,
        align: 'left',
        style: {
          fontSize: '16px',
          fontWeight: 'bold',
          color: '#e2e8f0'
        }
      },
      tooltip: {
        enabled: true,
        theme: 'dark',
      },
      xaxis: {
        type: 'datetime',
        labels: {
          style: {
            colors: '#94a3b8',
            fontSize: '10px',
          },
        },
        axisBorder: {
          show: false,
        },
        axisTicks: {
          show: false,
        },
      },
      yaxis: {
        tooltip: {
          enabled: true
        },
        labels: {
          style: {
            colors: '#94a3b8',
            fontSize: '10px',
          },
          formatter: function(value: number) {
            return '$' + value.toFixed(2);
          }
        }
      },
      grid: {
        show: true,
        borderColor: '#334155',
        strokeDashArray: 2,
        position: 'back',
      },
      plotOptions: {
        candlestick: {
          colors: {
            upward: '#10b981',
            downward: '#ef4444'
          },
          wick: {
            useFillColor: true,
          }
        }
      }
    };

    chartInstance.current = new ApexCharts(chartRef.current, options);
    chartInstance.current.render();

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
        chartInstance.current = null;
      }
    };
  }, [candlestickData, ticker]);

  return (
    <div className="candlestick-chart">
      <div ref={chartRef} className="w-full h-[400px]"></div>
    </div>
  );
};

export default CandlestickChart;