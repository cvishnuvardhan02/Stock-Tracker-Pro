import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { fetchQuote, fetchIndicator, fetchCandlestickData, fetchCompanyNews } from '../services/stockApi';

type ChartDataType = {
  labels: string[];
  prices: number[];
  sma: number[];
  ema: number[];
};

type CandlestickDataType = {
  x: Date;
  y: number[];
}[];

type NewsType = {
  datetime: number;
  headline: string;
  summary: string;
  url: string;
};

type StockInfoType = {
  ticker: string;
  name?: string;
};

type QuoteType = {
  c: number;  // Current price
  h: number;  // High price
  l: number;  // Low price
  o: number;  // Open price
  pc: number; // Previous close
};

type InvestmentStatusType = {
  message: string;
  type: 'success' | 'error' | 'info';
  purchasedPrice?: number;
};

interface StockContextType {
  ticker: string;
  chartData: ChartDataType;
  candlestickData: CandlestickDataType;
  news: NewsType[];
  currentStock: QuoteType | null;
  stockInfo: StockInfoType | null;
  isLoading: boolean;
  startTracking: (ticker: string) => void;
  balance: number;
  investedAmount: number;
  investmentStatus: InvestmentStatusType | null;
  investInStock: (amount: number) => void;
  sellStock: () => void;
}

const StockContext = createContext<StockContextType | undefined>(undefined);

export const StockProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [ticker, setTicker] = useState('');
  const [chartData, setChartData] = useState<ChartDataType>({
    labels: [],
    prices: [],
    sma: [],
    ema: []
  });
  const [candlestickData, setCandlestickData] = useState<CandlestickDataType>([]);
  const [news, setNews] = useState<NewsType[]>([]);
  const [currentStock, setCurrentStock] = useState<QuoteType | null>(null);
  const [stockInfo, setStockInfo] = useState<StockInfoType | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [intervalId, setIntervalId] = useState<number | null>(null);
  
  // Investment simulator state
  const [balance, setBalance] = useState(100000);
  const [investedAmount, setInvestedAmount] = useState(0);
  const [investmentStatus, setInvestmentStatus] = useState<InvestmentStatusType | null>(null);

  const fetchStockData = useCallback(async (symbol: string) => {
    try {
      const now = Math.floor(Date.now() / 1000);
      const fiveMinutesAgo = now - 300;
      
      const [quoteData, smaData, emaData, candlestick] = await Promise.all([
        fetchQuote(symbol),
        fetchIndicator(symbol, 'sma', fiveMinutesAgo, now, 5),
        fetchIndicator(symbol, 'ema', fiveMinutesAgo, now, 5),
        fetchCandlestickData(symbol),
      ]);
      
      if (quoteData) {
        setCurrentStock(quoteData);
        
        const time = new Date().toLocaleTimeString();
        
        setChartData(prev => {
          const newLabels = [...prev.labels, time];
          const newPrices = [...prev.prices, quoteData.c];
          const newSma = [...prev.sma, smaData?.sma?.at(-1) || null];
          const newEma = [...prev.ema, emaData?.ema?.at(-1) || null];
          
          // Keep only the last 20 data points
          if (newLabels.length > 20) {
            return {
              labels: newLabels.slice(-20),
              prices: newPrices.slice(-20),
              sma: newSma.slice(-20),
              ema: newEma.slice(-20)
            };
          }
          
          return {
            labels: newLabels,
            prices: newPrices,
            sma: newSma,
            ema: newEma
          };
        });
      }
      
      if (candlestick) {
        setCandlestickData(candlestick);
      }
      
      // Fetch news
      const newsData = await fetchCompanyNews(symbol);
      if (newsData) {
        setNews(newsData.slice(0, 10));
      }
      
    } catch (error) {
      console.error('Error fetching stock data:', error);
    }
  }, []);
  
  const startTracking = useCallback((symbol: string) => {
    setIsLoading(true);
    setTicker(symbol);
    setStockInfo({ ticker: symbol });
    
    // Reset charts
    setChartData({ labels: [], prices: [], sma: [], ema: [] });
    setCandlestickData([]);
    setNews([]);
    
    // Clear existing interval
    if (intervalId) {
      clearInterval(intervalId);
    }
    
    // Fetch initial data
    fetchStockData(symbol).then(() => {
      setIsLoading(false);
      
      // Start polling for data
      const id = window.setInterval(() => {
        fetchStockData(symbol);
      }, 10000);
      
      setIntervalId(id);
    });
  }, [fetchStockData, intervalId]);
  
  const investInStock = useCallback((amount: number) => {
    if (!currentStock || amount <= 0 || amount > balance) {
      setInvestmentStatus({
        message: 'Invalid investment amount.',
        type: 'error'
      });
      return;
    }
    
    setBalance(prev => prev - amount);
    setInvestedAmount(amount);
    setInvestmentStatus({
      message: `Invested $${amount.toFixed(2)} in ${ticker} at price $${currentStock.c.toFixed(2)}`,
      type: 'success',
      purchasedPrice: currentStock.c
    });
  }, [balance, currentStock, ticker]);
  
  const sellStock = useCallback(() => {
    if (investedAmount <= 0 || !currentStock || !investmentStatus?.purchasedPrice) {
      setInvestmentStatus({
        message: 'No active investment to sell.',
        type: 'error'
      });
      return;
    }
    
    const profitLoss = (currentStock.c - investmentStatus.purchasedPrice) * (investedAmount / investmentStatus.purchasedPrice);
    const total = investedAmount + profitLoss;
    
    setBalance(prev => prev + total);
    
    const isProfitable = profitLoss > 0;
    
    setInvestmentStatus({
      message: `Sold ${ticker} for $${total.toFixed(2)}. ${isProfitable ? 'Profit' : 'Loss'}: $${Math.abs(profitLoss).toFixed(2)}`,
      type: isProfitable ? 'success' : 'info'
    });
    
    setInvestedAmount(0);
  }, [investedAmount, currentStock, investmentStatus, ticker]);
  
  useEffect(() => {
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [intervalId]);
  
  return (
    <StockContext.Provider value={{
      ticker,
      chartData,
      candlestickData,
      news,
      currentStock,
      stockInfo,
      isLoading,
      startTracking,
      balance,
      investedAmount,
      investmentStatus,
      investInStock,
      sellStock
    }}>
      {children}
    </StockContext.Provider>
  );
};

export const useStockContext = () => {
  const context = useContext(StockContext);
  if (context === undefined) {
    throw new Error('useStockContext must be used within a StockProvider');
  }
  return context;
};